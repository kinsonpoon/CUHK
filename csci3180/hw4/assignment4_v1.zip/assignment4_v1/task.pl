/* Insert header here */

task(t1, 2, 4).
task(t2, 4, 6).
task(t3, 3, 7).
task(t4, 8, 9).
task(t5, 1, 10).
task(t6, 10, 1).

/* 1a */
check_task()
/* example query: check_task(t1); 
   result: yes */

/* 1b */
compatible()
/* example query: compatible(t1, t2); 
   result: yes */

/* 1c */
compatible_list()
/* example query: compatible_list([t1, t2, t3]);   
   result: no */

