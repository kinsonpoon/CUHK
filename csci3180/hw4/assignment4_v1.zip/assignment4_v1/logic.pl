/* Insert header here */

/* 1a */
uint_num()

/* 1b */
gt()

/* 1c */
/* Your query */

/* 1d */
product()

/* 1e */
/* Your query */

/* 1f */
/* Your query */

/* 2a */
nth()

/* 2b */
third()

