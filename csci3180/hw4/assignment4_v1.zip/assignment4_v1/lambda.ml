(* Insert header here *)

(* 2c *)
fun f x y = ;
(* Example query: f 7 8 *)

