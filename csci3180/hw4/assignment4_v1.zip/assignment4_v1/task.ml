(* Insert header here *)

val tasks = [
  ("t1", 2, 4),
  ("t2", 4, 6),
  ("t3", 3, 7),
  ("t4", 8, 9),
  ("t5", 1, 10),
  ("t6", 10, 1)
];

(* 1a *)
fun check_task()
(* example query: check_task("t1", tasks); *)
(* result: val it = true : bool *)

(* 1b *)
fun compatible()
(* example query: compatible("t1", "t2", tasks); *)
(* result: val it = true : bool *)

(* 1c *)
fun compatible_list()
(* example query: compatible_list(["t1", "t2", "t3"], tasks); *)
(* result: val it = false : bool *)

